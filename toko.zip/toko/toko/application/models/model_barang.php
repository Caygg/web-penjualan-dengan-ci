<?php

class model_barang extends ci_model{

	public function tampil_data(){
		return $this->db->get('tbl_barang');
	}
}